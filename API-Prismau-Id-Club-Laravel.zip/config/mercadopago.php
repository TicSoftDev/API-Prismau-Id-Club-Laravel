<?php

return [
    'access_token' => "APP_USR-1335478149541042-101121-a36d1d0b6e84c4a77e92c2062f326f9b-2033404684",
];
